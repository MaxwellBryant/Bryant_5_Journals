﻿The mango picture was just used for my FavIcon. I will most likely be using this in the future; to try to make a mark on my work if you will.
