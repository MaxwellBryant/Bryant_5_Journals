window.alert("Hello there!");

 var r = confirm("Shall we continue?");
if (r == true) {
    x = "You pressed okay!";
} else if (r == false) {
    x = "You pressed cancel!";
    window.alert("YOU SHALL NOT SEE THE WEBSITE!");
    window.stop();
}