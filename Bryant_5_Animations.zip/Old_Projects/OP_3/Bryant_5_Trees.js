function drawBranches (context, startX, startY, trunkWidth, level) {
    if (level < 12) {
        var changeX = 100 / (level + 1);
        var changeY = 200 / (level + 1);
        
        var topRightX = startX + Math.random() * changeX;
        var topRightY = startY - Math.random() * changeY;
        
        var topLeftX = startX - Math.random() * changeX;
        var topLeftY = startY - Math.random() * changeY;
        
        // draw right branch
        context.beginPath();
        context.strokeStyle = "#885A2D";
        context.moveTo(startX + trunkWidth / 4, startY);
        context.quadraticCurveTo(startX + trunkWidth / 4, startY - trunkWidth, topRightX, topRightY);
        context.lineWidth = trunkWidth;
        context.lineCap = "round";
        context.stroke();
        
        // draw left branch
        context.beginPath();
        context.strokeStyle = "#A6784B";
        context.moveTo(startX - trunkWidth / 4, startY);
        context.quadraticCurveTo(startX - trunkWidth / 4, startY - trunkWidth, topLeftX, topLeftY);
        context.lineWidth = trunkWidth;
        context.lineCap = "round";
        context.stroke();
        
        drawBranches(context, topRightX, topRightY, trunkWidth * 0.6, level + 1);
        drawBranches(context, topLeftX, topLeftY, trunkWidth * 0.6, level + 1);
    }
}

window.onload = function() {
    canvas = document.getElementById("Canvas1");
    context = canvas.getContext("2d");
    
    drawBranches(context, canvas.width / 2, canvas.height, 40, 0);
};