var thing = true;
function clickOff() {
    if (thing === true) {
        'use scrict';
        var change1 = document.getElementById("head"),
            change2 = document.getElementById("body"),
            change3 = document.getElementById("art1"),
            change4 = document.getElementById("art2"),
            change5 = document.getElementById("art3");
        
        change1.style.backgroundColor = '#353588';
        change1.innerHTML = "Night theme!";
        change1.style.color = '#51519E';
        change2.style.backgroundColor = '#212171';
        change3.style.backgroundColor = '#353588';
        change3.style.color = '#51519E';
        change4.style.backgroundColor = '#353588';
        change4.style.color = '#51519E';
        change5.style.backgroundColor = '#353588';
        change5.style.color = '#51519E';
            thing = false;
        
    } else {
        
        var change1 = document.getElementById("head"),
            change2 = document.getElementById("body"),
            change3 = document.getElementById("art1"),
            change4 = document.getElementById("art2"),
            change5 = document.getElementById("art3");
        
        change1.style.backgroundColor = '#658414';
        change1.innerHTML = "Day theme!";
        change1.style.color = '#A7C755';
        change2.style.backgroundColor = '#85A630';
        change3.style.backgroundColor = '#658414';
        change3.style.color = '#A7C755';
        change4.style.backgroundColor = '#658414';
        change4.style.color = '#A7C755';
        change5.style.backgroundColor = '#658414';
        change5.style.color = '#A7C755';
            thing = true;
    }
};

function over() {
    'use strict';
    var change = document.getElementById("footer");
    change.style.backgroundColor = '#FFF';
    change.style.color = '#000';
};

function off() {
    'use strict';
    var change = document.getElementById("footer");
    change.style.backgroundColor = '#000';
    change.style.color = '#FFF';
};

function choice(a) {
    if (a == 0) {
        document.getElementById("spot").innerHTML = "<img src = 'Rock.png'>";
    }
    else if (a == 1) {
        document.getElementById("spot").innerHTML = "<img src = 'Paper.png'>";
    }
    else if (a == 2) {
        document.getElementById("spot").innerHTML = "<img src = 'Scissors.png'>";
    }
};