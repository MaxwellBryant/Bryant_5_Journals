var person = prompt("Pick a name!");

var name1 = "Macy";
var name2 = "Mike";

var nouns = ["monkey", "beach", "Walmart"];
var verbs = ["kissed", "killed", "snorted"];
var adjs = ["weird", "crazy", "exciting", "strenuous"];
var advs = ["quietly", "fabulously", "deviously"];
var preps = ["around", "right", "left"];

var num1 = Math.floor((Math.random() * 4) + 0);
var num2 = Math.floor((Math.random() * 3) + 0);
var num3 = Math.floor((Math.random() * 4) + 0);
var num4 = Math.floor((Math.random() * 3) + 0);
var num5 = Math.floor((Math.random() * 3) + 0);
var num6 = Math.floor((Math.random() * 3) + 0);
var num7 = Math.floor((Math.random() * 4) + 0);
var num8 = Math.floor((Math.random() * 3) + 0);
var num9 = Math.floor((Math.random() * 3) + 0);
var num10 = Math.floor((Math.random() * 4) + 0);

/* document.write(num1 + "," + num2 + "," + num3 + "," + num4); */

document.write("One day,  " + person + " woke-up confused.");
document.write(" " + name2 + " asked, what's wrong " + person + "?");
document.write(" Well, I had this " + adjs[num1] + " dream where I " + verbs[num2] + " a " + nouns[num2] + ", and liked it!");
document.write(" That's " + adjs[num3] + "!" + " I want you to feel good about this dream, " + name2 + " said.");
document.write(" Oh please, " + name2 + ", you can't even turn " + preps[num4] + " without " + advs[num5] + " crying in your room! " + name1 + " said sternly.");
document.write(" I could even bet my " + nouns[num6] + " on this! " + name1 + " added.");
document.write(" Guys, guys! Stop the fighting! " + person + " explained. I thought we were talking about my " + adjs[num7] + " dream!");
document.write(" You're right " + person + ", we should stop, and to think, I almost " + verbs[num8] + " " + name1 + ".");
document.write(" " + name2 + " then realized he needed to stop, so he walked away " + advs[num9] + " while thinking about all of the " + adjs[num10] + " things that happened today in " + person + "'s dream.");