var k = prompt("Pick a number");
var r = prompt("Pick another number");
var d = (k + r);
var num1 = parseInt(k);
var num2 = parseInt(r);
var num3 = num1 + num2;

document.write("This is how math works in JavaScript. ");
document.write("K is " + k + " R is " + r + " D is K + R and it's " + num3 + ". ");
document.write("Multiplication = ");
document.write(k * r + " | ");
document.write("Division = ");
document.write(k / r + " | ");
document.write("Addition = ");
document.write(num3 + " | ");
document.write("Subtraction = ");
document.write(k - r + " | ");
document.getElementById("p2").style.color = "red";

if (k == r) {
    document.write("K and R are the same!");
} else if (k < r) {
    document.write("K is less than R.");
} else if (k > r) {
    document.write("K is greater than R.");
}

/* We parseInt variables so that variables would be treated as INTS and not Strings. */