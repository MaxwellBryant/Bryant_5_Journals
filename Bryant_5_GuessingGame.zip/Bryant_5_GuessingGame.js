var person = prompt("What is your name?");
var number = Math.floor((Math.random() * 10) + 1);
var guess;

    window.alert("Okay " + person + ", here are the rules... You must guess the number correctly. Take note that every round brings more difficulty.");

    guess = prompt("Pick a number 1 through 10, you get unlimited guesses for a warm-up.");

while (number != guess) {

if (guess > number) {
    guess = prompt("You are too high, guess lower.");
}

else if (guess < number) {
    guess = prompt("You are too low, guess higher.");
}
    
else if (guess == number) {
    window.alert("You have successfully guessed my number. Next time, it won't be so easy...");
    }
}